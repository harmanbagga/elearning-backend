# node-mongo-registration-login-api

NodeJS + MongoDB API for User Management, Authentication and Registration

For documentation and instructions check out http://jasonwatmore.com/post/2018/06/14/nodejs-mongodb-simple-api-for-authentication-registration-and-user-management